readme

xUSSR Railway Set v0.8

The xUSSR Railway Set includes locomotives, DMUs, EMUs and other rolling stock
from the former Russian Empire, Soviet Union and several countries containing
former U.S.S.R. All the vehicles are drawn in realistic extended scale,
exceeding original Transport Tycoon graphics. All technical features such as
power, tractive effort, capacity, production date are based on peculiarities
and functionality of real vehicles.

Copyright (C) 2004-2023 by AgRiG, George (George V. Bagaev), Wowan (Vladimir
Guryanov), Simozzz (Andrey Kashirin), dvornik (Alexander Kozlov), Joyrider
(Anton Murashov), Ghost (Serguei Stepanov), Rubiroid (Alexander Tkachuk),
Engineer_Keen (Vasiliy Verigin), Otecan (Andrey Pichugin), LitNik (Nikolay
Litvinenko), pi1985 (Ivan Piskovoy), AliceAllst (Arkadiy Hirosava),
Rau117 (Nikita Mikhailov).

Special thanks to: Oleg, STD.

Created using the NML.
